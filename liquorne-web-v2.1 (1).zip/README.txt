Liquorne — prototype web V2.1

Nouveautés :
- Page login (logo + user/password) et entrée dans l'app si login OK
- KPI (Possédés/Goûtés/Wishlist + note moyenne)
- Tri (note, nom, ABV)
- Persistance localStorage : avis + cave + session

Identifiants démo :
- demo / liquorne

Si le logo n'apparaît pas après mise à jour GitHub Pages :
- sur Android Chrome : menu ⋮ → Paramètres → Confidentialité → Effacer données de navigation (cache)
- ou désinstaller/réinstaller l'icône PWA